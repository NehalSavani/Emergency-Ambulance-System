# Viva Questions and Answers

1. **How is the road network modeled?** An undirected weighted graph with an adjacency list. Nodes are intersections and edges are roads with simulated travel cost.
2. **How does Dijkstra work?** It repeatedly extracts the unsettled node with lowest known cost and relaxes each outgoing edge.
3. **What does A* add?** It prioritizes by `f(n)=g(n)+h(n)`, combining cost already travelled with an estimate to the goal.
4. **How is the A* heuristic calibrated?** The graph records the minimum ratio `edge_cost / coordinate_distance` over all edges. A* multiplies that scale by Euclidean distance to the goal.
5. **Why is the calibrated heuristic admissible?** Every edge cost is at least the calibrated scale times its coordinate length. By the triangle inequality, any multi-edge route costs at least the same scale times direct Euclidean distance, so the heuristic cannot overestimate.
6. **Is A* always faster?** No. Poor heuristics, ties, graph geometry, and machine timing can make it similar to or slower than Dijkstra.
7. **Why use a priority queue?** A min-heap efficiently retrieves the next lowest-priority frontier node.
8. **How is the route reconstructed?** Each relaxation records a predecessor; following predecessors backward from the goal yields the path.
9. **What are complexities?** With an adjacency list and binary heap, worst-case time is O((V+E) log V), and auxiliary search space is O(V), or O(V+E) including the graph.
10. **What if no path exists?** The goal never enters the predecessor map; the result returns `found=false` and an empty path.
11. **What does traffic mean here?** It is explicitly simulated by multiplying edge costs; it is not live traffic data.
12. **How were results measured?** Each graph size is generated with controlled seeds and each algorithm is run over seven trials; raw measurements are written to CSV.
13. **Why compare nodes explored and time?** Nodes explored reveals search behavior; time captures practical implementation cost, while both are machine-dependent.
14. **What would you improve?** Real road data, turn restrictions, time-dependent traffic, multiple ambulances, and a stronger geographic visualization.
