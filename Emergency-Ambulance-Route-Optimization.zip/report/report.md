# Emergency Ambulance Route Optimization System

**DAA 5th Semester Mini Project Report**

- Group: [GROUP NUMBER]
- Students: [STUDENT 1 NAME], [STUDENT 2 NAME], [STUDENT 3 NAME], [STUDENT 4 NAME]
- Faculty: [FACULTY NAME]
- Submission date: [SUBMISSION DATE]

## 1. Problem Definition
Emergency response teams need a low-cost route between an ambulance and hospital. This project models a weighted road graph and compares Dijkstra with A* on a locally generated synthetic network. No live traffic or commercial mapping service is claimed.

## 2. Objectives
Model intersections and roads with an adjacency list; implement Dijkstra and A* from scratch; expose path, cost, explored nodes and execution time; compare input sizes; create reproducible tests and evidence.

## 3. Background / Existing Approach
Dijkstra finds shortest paths with non-negative costs. A* adds a heuristic to direct the search toward the goal. Real systems may use GIS and dynamic traffic; this project remains self-contained for explainability.

## 4. Proposed Approach
Build a connected synthetic city grid with coordinates and positive edge weights. The Flask interface calls the same Python implementations used in benchmarks and visualizes the returned paths.

## 5. Algorithm Selection and Justification
Dijkstra is the correctness baseline. A* uses a graph-calibrated heuristic: it multiplies Euclidean distance by the minimum observed edge-cost / coordinate-distance ratio. This preserves admissibility by the triangle inequality while matching the graph's cost scale. A* is not always faster; performance depends on graph structure, heap behavior, and machine timing.

## 6. Algorithm / Pseudocode
Dijkstra repeatedly extracts the least-cost frontier node and relaxes outgoing edges. A* uses f(n)=g(n)+h(n), where g is cost-so-far and h is the graph-calibrated Euclidean lower bound. The scale is the minimum edge_cost / coordinate_distance ratio observed in the graph. Every edge satisfies cost ≥ scale × coordinate length; by the triangle inequality, the heuristic cannot overestimate any route. Predecessors reconstruct the path.

## 7. Complexity Analysis
With an adjacency list and binary min-heap, both algorithms have worst-case time O((V+E) log V) and O(V+E) space including the graph. The source=goal best case is O(1); average behavior is input-dependent.

## 8. System Design and Implementation
Python, Flask, HTML/CSS/JavaScript, pytest, and matplotlib are used. graph/ stores the model; algorithms/ stores the searches; benchmarking/ writes CSV/JSON and charts; tests/ verifies behavior.

## 9. Testing with Different Input Sizes
Automated tests cover equal optimal costs, same-node routes, no-path handling, and valid path edges. Benchmarks use 10, 50, 100 and 500 requested nodes, seven trials per size, and controlled seeds.

## 10. Results and Performance Comparison
The run produced **56 raw measurements** (4 sizes × 2 algorithms × 7 trials) after replacing the weak normalized-distance heuristic. The table contains actual averages from the regenerated `results/benchmark_results.csv`.

| Input size | Dijkstra ms | A* ms | Dijkstra nodes | A* nodes |
|---:|---:|---:|---:|---:|
| 10 | 0.0120 | 0.0111 | 7.29 | 4.00 |
| 50 | 0.0440 | 0.0305 | 33.43 | 12.86 |
| 100 | 0.1125 | 0.1270 | 100.00 | 64.14 |
| 500 | 0.6367 | 0.6420 | 482.29 | 295.57 |

The calibrated heuristic reduced A* node expansions at every measured size: from 7.29 to 4.00, 33.43 to 12.86, 100.00 to 64.14, and 482.29 to 295.57. Execution time is mixed: A* was faster at sizes 10 and 50, but slightly slower at 100 and 500 in this run. This is honest evidence that fewer expansions do not guarantee lower wall-clock time because heuristic calculations and heap operations also have costs, and timings are machine-dependent.

Charts: `results/performance_time.png` and `results/performance_nodes.png` were regenerated from these measurements.
## 11. Screenshots of Working Project
Screenshots captured from the running Flask app are stored in screenshots/.

## 12. Advantages and Limitations
Advantages: explainable algorithms, offline reproducibility and direct evidence. Limitations: synthetic network, simulated costs and no dispatch-grade GIS.

## 13. Future Scope
Use verified road data, time-dependent costs, incident modeling, turn restrictions, multiple ambulances and richer geographic visualization.

## 14. Conclusion
The project demonstrates graph modeling, algorithm design, implementation, testing, complexity analysis and measured comparison.

## 15. References
1. Dijkstra, E. W. (1959), A Note on Two Problems in Connexion with Graphs.
2. Hart, Nilsson and Raphael (1968), A Formal Basis for the Heuristic Determination of Minimum Cost Paths.
3. Python heapq documentation.
4. Flask documentation.