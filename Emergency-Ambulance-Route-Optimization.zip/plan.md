# Implementation Plan

## Product
An offline Flask dashboard for an Emergency Ambulance Route Optimization System. It compares hand-written Dijkstra and A* search on a locally generated weighted graph.

## Design direction
- **Movement:** mission-control utility interface: dark navy workspace, high-contrast emergency red, cyan route telemetry.
- **Principles:** legibility first, evidence over decoration, compact operational density, explainable interactions.
- **Layout:** asymmetric split-screen dashboard: controls and algorithm cards on the left; large live route map and benchmark evidence on the right.
- **Signature elements:** route telemetry chips, glowing path lines, and a “dispatch ready” status rail.
- **Typography:** Inter/system sans for UI, IBM Plex Mono fallback for metrics and pseudocode.

## Architecture
- `graph/`: graph model and deterministic synthetic road-network generation.
- `algorithms/`: readable from-scratch Dijkstra and A* implementations.
- `benchmarking/`: repeatable measurements and chart generation.
- `templates/`, `static/`: Flask-rendered dashboard.
- `tests/`: algorithm and graph behavior tests.
- `report/`: academic report source and generated DOCX/PDF if available.

## Required behavior
The app supports source/destination selection, network scenarios, running either algorithm or both, side-by-side metrics, route visualization, and links to measured benchmark results. No external map, API key, or live traffic is used.
