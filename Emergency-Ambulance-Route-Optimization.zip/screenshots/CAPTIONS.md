# Screenshot Captions

- `01_input_standby.webp`: working Flask interface showing dispatch controls, synthetic network map, legend, and standby state.
- `02_computed_route.webp`: working Flask interface after running both algorithms, showing equal route cost, nodes explored, execution time, and the route path.
